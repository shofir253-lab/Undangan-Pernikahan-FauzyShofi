<?php
session_start();
include "../konfig/database.php";

$user = $_POST['username'];
$pass = md5($_POST['password']);

$q = mysqli_query($conn,"SELECT * FROM admin WHERE username='$user' AND password='$pass'");
if(mysqli_num_rows($q) > 0){
  $_SESSION['admin'] = $user;
  header("Location: dashboard.php");
}else{
  echo "<script>alert('Login gagal');location='login.php'</script>";
}