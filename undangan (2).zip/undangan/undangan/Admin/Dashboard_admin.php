<?php
session_start();
if(!isset($_SESSION['admin'])) header("Location: login.php");
include "../konfig/database.php";
$data = mysqli_query($conn,"SELECT * FROM rsvp ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<style>
body{background:#0b0b0b;color:#fff;font-family:Montserrat;padding:20px}
h2{color:#ffdca8}
table{
  width:100%;
  background:#111;
  border-radius:14px;
  overflow:hidden;
}
th,td{padding:12px;font-size:14px}
th{background:#ffdca8;color:#000}
tr:nth-child(even){background:#1a1a1a}
a{color:#ff6b6b;text-decoration:none}
.logout{
  display:inline-block;
  margin-bottom:15px;
  background:#ffdca8;
  padding:8px 14px;
  border-radius:12px;
  color:#000;
}
</style>
</head>

<body>
<a class="logout" href="logout.php">Logout</a>
<h2>DATA RSVP & WISHES</h2>

<table>
<tr>
<th>Nama</th>
<th>Ucapan</th>
<th>Kehadiran</th>
<th>Tanggal</th>
</tr>

<?php while($r=mysqli_fetch_assoc($data)): ?>
<tr>
<td><?= $r['nama'] ?></td>
<td><?= $r['ucapan'] ?></td>
<td><?= $r['kehadiran'] ?></td>
<td><?= $r['created_at'] ?></td>
</tr>
<?php endwhile; ?>

</table>
</body>
</html>