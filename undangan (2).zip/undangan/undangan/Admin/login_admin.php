<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<style>
body{
  background:#0d0d0d;
  display:flex;
  justify-content:center;
  align-items:center;
  height:100vh;
  font-family:Montserrat;
}
.card{
  background:linear-gradient(135deg,#ffdca8,#e8c48f);
  padding:30px;
  border-radius:18px;
  width:280px;
}
input,button{
  width:100%;
  padding:12px;
  margin-top:12px;
  border-radius:14px;
  border:none;
}
button{
  background:#000;
  color:#ffdca8;
  font-weight:600;
}
</style>
</head>
<body>

<form class="card" method="POST" action="auth.php">
<h3 style="text-align:center">ADMIN LOGIN</h3>
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button>LOGIN</button>
</form>

</body>
</html>