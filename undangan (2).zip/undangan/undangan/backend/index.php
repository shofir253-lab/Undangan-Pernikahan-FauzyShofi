<?php
include "config/database.php";

$nama = $_GET['to'] ?? '';
$code = $_GET['code'] ?? '';

$cek = mysqli_query($conn, "SELECT * FROM tamu WHERE kode_tamu='$code'");
$valid = mysqli_num_rows($cek) > 0;
?>

<section id="rsvp">
  <h2>Ucapan & Doa</h2>

<?php if(!$valid): ?>
  <div class="alert">Mohon maaf! Khusus untuk tamu undangan</div>
<?php else: ?>
  <form action="process/simpan_rsvp.php" method="POST">
    <input type="hidden" name="nama" value="<?= htmlspecialchars($nama) ?>">

    <textarea name="ucapan" required placeholder="Tulis ucapan"></textarea>

    <select name="kehadiran" required>
      <option value="">Konfirmasi Kehadiran</option>
      <option value="Hadir">Hadir</option>
      <option value="Tidak Hadir">Tidak Hadir</option>
    </select>

    <button type="submit">Kirim</button>
  </form>
<?php endif; ?>
</section>