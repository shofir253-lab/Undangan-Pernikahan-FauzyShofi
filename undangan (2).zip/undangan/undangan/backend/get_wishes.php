<?php
require 'db.php';

$stmt = $pdo->query("SELECT * FROM wishes ORDER BY created_at DESC");
$wishes = $stmt->fetchAll();

echo json_encode($wishes);
?>
