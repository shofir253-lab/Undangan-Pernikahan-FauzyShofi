<?php
require 'db.php';

// Ambil data dari AJAX / form
$guest_name = $_POST['guest_name'] ?? '';
$attendance = $_POST['attendance'] ?? '';
$message = $_POST['message'] ?? '';

if(empty($guest_name) || empty($attendance)){
    echo json_encode(['status' => 'error', 'message' => 'Nama dan konfirmasi wajib diisi!']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO wishes (guest_name, attendance, message) VALUES (?, ?, ?)");
if($stmt->execute([$guest_name, $attendance, $message])){
    echo json_encode(['status' => 'success', 'message' => 'Terima kasih atas konfirmasi dan ucapan Anda!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan data.']);
}
?>
