<?php
include "konfig.php";

$data = json_decode(file_get_contents("php://input"), true);

$name   = $data['name'];
$status = $data['status'];
$note   = $data['note'];

mysqli_query($conn,"
INSERT INTO rsvp (nama, kehadiran, ucapan, waktu)
VALUES ('$name','$status','$note',NOW())
");

echo json_encode(["success"=>true]);
