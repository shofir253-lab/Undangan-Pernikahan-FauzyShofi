<?php
$conn = new mysqli("localhost", "root", "", "undangan");
if ($conn->connect_error) {
  die("Koneksi gagal");
}

$sql = "SELECT type, info, description FROM tb_gift ORDER BY id ASC";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data);