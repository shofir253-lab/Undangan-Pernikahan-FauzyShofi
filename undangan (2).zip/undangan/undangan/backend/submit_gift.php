<?php
require 'db.php';

$sender_name = $_POST['sender_name'] ?? '';
$amount = $_POST['amount'] ?? '';
$message = $_POST['message'] ?? '';

if(empty($amount)){
    echo json_encode(['status' => 'error', 'message' => 'Jumlah wajib diisi!']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO gifts (sender_name, amount, message) VALUES (?, ?, ?)");
if($stmt->execute([$sender_name, $amount, $message])){
    echo json_encode(['status' => 'success', 'message' => 'Terima kasih atas hadiah Anda!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan data.']);
}
?>
